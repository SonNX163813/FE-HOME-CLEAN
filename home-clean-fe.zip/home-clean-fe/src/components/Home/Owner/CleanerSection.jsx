import { useContext, useEffect, useState } from "react";
import { WebSocketContext } from "../../../context/WebSocketContext";
import { AuthContext } from "../../../context/AuthContext";
import axios from "axios";
import CleanerCard from "./CleanerCard";

function CleanerSection() {
  const [cleaners, setCleaners] = useState([]);
  const [onlineCleanerIds, setOnlineCleanerIds] = useState([]);

  const { token } = useContext(AuthContext);
  const client = useContext(WebSocketContext);

  // Fetch danh sách cleaner
  useEffect(() => {
    const fetchAllCleaners = async () => {
      try {
        const res = await axios.get("http://localhost:8080/api/customer/cleaners/online", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        setCleaners(res.data);
        const ids = res.data.map((cleaner) => cleaner.cleanerId);
        setOnlineCleanerIds(ids);
      } catch (error) {
        console.error("❌ Lỗi khi fetch cleaners:", error);
      }
    };

    if (token) fetchAllCleaners();
  }, [token]);

  // Subscribe khi WebSocket client ready
  useEffect(() => {
    if (!client) return;

    const trySub = () => {
      const subscription = client.subscribe("/topic/onlineCleaners", (message) => {
        try {
          const onlineCleaners = JSON.parse(message.body);
          const ids = onlineCleaners.map((c) => c.cleanerId);
          setOnlineCleanerIds(ids);
        } catch (error) {
          console.error("❌ Lỗi khi nhận onlineCleaners:", error);
        }
      });

      return subscription;
    };

    if (client.connected) {
      const sub = trySub();
      return () => sub?.unsubscribe();
    } else {
      client.onConnect = () => {
        const sub = trySub();
        client.cleanupSub = () => sub?.unsubscribe();
      };

      return () => {
        if (client.cleanupSub) {
          client.cleanupSub();
        }
      };
    }
  }, [client]);

  const isOnline = (cleanerId) => onlineCleanerIds.includes(cleanerId);

  return (
    <section className="service-section">
      <h2 className="section-title">Danh sách cleaner</h2>
      <div style={{ display: "flex", gap: 15, flexWrap: "wrap" }}>
        {cleaners.length > 0 ? (
          cleaners.map((cleaner) => (
            <CleanerCard
              key={cleaner.cleanerId}
              cleanerId={cleaner.cleanerId}
              cleanerImg={cleaner.profileImage}
              cleanerName={cleaner.cleanerName}
              rating={4.6}
              reviews={100}
              isOnline={isOnline(cleaner.cleanerId)}
            />
          ))
        ) : (
          <p>Đang tải danh sách cleaner...</p>
        )}
      </div>
    </section>
  );
}

export default CleanerSection;
